/*************************************************************************
                           Trajet  -  description
                             -------------------
    début                : $21-11-2022$
    copyright            : (C) $2022$ par $Binôme3307$
    e-mail               : youssef.sidhom@insa-lyon.fr/mohamed.fayala@insa-lyon.fr
************************************************************************/

//---------- Réalisation de la classe <Trajet> (fichier Trajet.cpp) ------------

//---------------------------------------------------------------- INCLUDE
//------------------------------------------------------ Include personnel
#include "Trajet.h"



//-------------------------------------------- Constructeurs - destructeur

Trajet::~Trajet ( ){

}