/*************************************************************************
                           main  -  description
-------------------
    début                : $21-11-2022$
    copyright            : (C) $2022$ par $Binôme3307$
        e-mail               : youssef.sidhom@insa-lyon.fr/mohamed.fayala@insa-lyon.fr
*************************************************************************/

//---------- Réalisation de la classe <main> (fichier main.cpp) ------------

//---------------------------------------------------------------- INCLUDE

//-------------------------------------------------------- Include système
using namespace std;
#include <cstring>
#include <iostream>
//------------------------------------------------------ Include personnel
#include "Catalogue.h"
//------------------------------------------------------------- Constantes

//----------------------------------------------------------------- PUBLIC

//----------------------------------------------------- Méthodes publiques

int main(){
    Catalogue monCatalogue;
    monCatalogue.Interface();

    return 0;
}